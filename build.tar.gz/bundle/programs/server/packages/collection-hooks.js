(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var _ = Package.underscore._;
var EJSON = Package.ejson.EJSON;
var MongoInternals = Package['mongo-livedata'].MongoInternals;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var Deps = Package.deps.Deps;

/* Package-scope variables */
var CollectionHooks, docIds;

(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/bind-polyfill.js                                                                    //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Function/bind                // 1
                                                                                                                 // 2
if (!Function.prototype.bind) {                                                                                  // 3
  Function.prototype.bind = function (oThis) {                                                                   // 4
    if (typeof this !== "function") {                                                                            // 5
      // closest thing possible to the ECMAScript 5 internal IsCallable function                                 // 6
      throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");               // 7
    }                                                                                                            // 8
                                                                                                                 // 9
    var aArgs = Array.prototype.slice.call(arguments, 1),                                                        // 10
        fToBind = this,                                                                                          // 11
        fNOP = function () {},                                                                                   // 12
        fBound = function () {                                                                                   // 13
          return fToBind.apply(this instanceof fNOP && oThis                                                     // 14
                                 ? this                                                                          // 15
                                 : oThis,                                                                        // 16
                               aArgs.concat(Array.prototype.slice.call(arguments)));                             // 17
        };                                                                                                       // 18
                                                                                                                 // 19
    fNOP.prototype = this.prototype;                                                                             // 20
    fBound.prototype = new fNOP();                                                                               // 21
                                                                                                                 // 22
    return fBound;                                                                                               // 23
  };                                                                                                             // 24
}                                                                                                                // 25
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/collection-hooks.js                                                                 //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// Relevant AOP terminology:                                                                                     // 1
// Aspect: User code that runs before/after (hook)                                                               // 2
// Advice: Wrapper code that knows when to call user code (aspects)                                              // 3
// Pointcut: before/after                                                                                        // 4
                                                                                                                 // 5
var advices = {};                                                                                                // 6
var currentUserId;                                                                                               // 7
var constructor = Meteor.Collection;                                                                             // 8
var proto = new Meteor.Collection(null);                                                                         // 9
var directEnv = new Meteor.EnvironmentVariable();                                                                // 10
var directOp = function (func) {                                                                                 // 11
  return directEnv.withValue(true, func);                                                                        // 12
};                                                                                                               // 13
                                                                                                                 // 14
function getUserId() {                                                                                           // 15
  var userId;                                                                                                    // 16
                                                                                                                 // 17
  if (Meteor.isClient) {                                                                                         // 18
    Deps.nonreactive(function () {                                                                               // 19
      userId = Meteor.userId && Meteor.userId();                                                                 // 20
    });                                                                                                          // 21
  }                                                                                                              // 22
                                                                                                                 // 23
  if (Meteor.isServer) {                                                                                         // 24
    try {                                                                                                        // 25
      // Will throw an error unless within method call.                                                          // 26
      // Attempt to recover gracefully by catching:                                                              // 27
      userId = Meteor.userId && Meteor.userId();                                                                 // 28
    } catch (e) {}                                                                                               // 29
                                                                                                                 // 30
    if (!userId) {                                                                                               // 31
        userId = currentUserId;                                                                                  // 32
    }                                                                                                            // 33
  }                                                                                                              // 34
                                                                                                                 // 35
  return userId;                                                                                                 // 36
}                                                                                                                // 37
                                                                                                                 // 38
CollectionHooks = {};                                                                                            // 39
                                                                                                                 // 40
CollectionHooks.extendCollectionInstance = function (self) {                                                     // 41
  // Offer a public API to allow the user to define aspects                                                      // 42
  // Example: collection.before.insert(func);                                                                    // 43
  _.each(["before", "after"], function (pointcut) {                                                              // 44
    _.each(advices, function (advice, method) {                                                                  // 45
      Meteor._ensure(self, pointcut, method);                                                                    // 46
      Meteor._ensure(self, "_aspects", method);                                                                  // 47
                                                                                                                 // 48
      self._aspects[method][pointcut] = [];                                                                      // 49
      self[pointcut][method] = function (aspect) {                                                               // 50
        var len = self._aspects[method][pointcut].push(aspect);                                                  // 51
        return {                                                                                                 // 52
          replace: function (aspect) {                                                                           // 53
            self._aspects[method][pointcut].splice(len - 1, 1, aspect);                                          // 54
          },                                                                                                     // 55
          remove: function () {                                                                                  // 56
            self._aspects[method][pointcut].splice(len - 1, 1);                                                  // 57
          }                                                                                                      // 58
        };                                                                                                       // 59
      };                                                                                                         // 60
    });                                                                                                          // 61
  });                                                                                                            // 62
                                                                                                                 // 63
  // Wrap mutator methods, letting the defined advice do the work                                                // 64
  _.each(advices, function (advice, method) {                                                                    // 65
    // Store a reference to the mutator method in a publicly reachable location                                  // 66
    var _super = Meteor.isClient ? self[method] : self._collection[method];                                      // 67
                                                                                                                 // 68
    Meteor._ensure(self, "direct", method);                                                                      // 69
    self.direct[method] = function () {                                                                          // 70
      if (directEnv.get() === true) return;                                                                      // 71
      return directOp(function () {                                                                              // 72
        return _super.bind(Meteor.isClient ? self : self._collection);                                           // 73
      });                                                                                                        // 74
    };                                                                                                           // 75
                                                                                                                 // 76
    (Meteor.isClient ? self : self._collection)[method] = function () {                                          // 77
      return advice.call(this,                                                                                   // 78
        getUserId(),                                                                                             // 79
        _super,                                                                                                  // 80
        self._aspects[method] || {},                                                                             // 81
        function (doc) {                                                                                         // 82
          return  _.isFunction(self._transform)                                                                  // 83
                  ? function (d) { return self._transform(d || doc); }                                           // 84
                  : function (d) { return d || doc; };                                                           // 85
        },                                                                                                       // 86
        _.toArray(arguments)                                                                                     // 87
      );                                                                                                         // 88
    };                                                                                                           // 89
  });                                                                                                            // 90
};                                                                                                               // 91
                                                                                                                 // 92
CollectionHooks.defineAdvice = function (method, advice) {                                                       // 93
  advices[method] = advice;                                                                                      // 94
};                                                                                                               // 95
                                                                                                                 // 96
CollectionHooks.getDocs = function (collection, selector, options) {                                             // 97
  var self = this;                                                                                               // 98
                                                                                                                 // 99
  var findOptions = {transform: null, reactive: false}; // added reactive: false                                 // 100
                                                                                                                 // 101
  /*                                                                                                             // 102
  // No "fetch" support at this time.                                                                            // 103
  if (!self._validators.fetchAllFields) {                                                                        // 104
    findOptions.fields = {};                                                                                     // 105
    _.each(self._validators.fetch, function(fieldName) {                                                         // 106
      findOptions.fields[fieldName] = 1;                                                                         // 107
    });                                                                                                          // 108
  }                                                                                                              // 109
  */                                                                                                             // 110
                                                                                                                 // 111
  // Bit of a magic condition here... only "update" passes options, so this is                                   // 112
  // only relevant to when update calls getDocs:                                                                 // 113
  if (options) {                                                                                                 // 114
    // This was added because in our case, we are potentially iterating over                                     // 115
    // multiple docs. If multi isn't enabled, force a limit (almost like                                         // 116
    // findOne), as the default for update without multi enabled is to affect                                    // 117
    // only the first matched document:                                                                          // 118
    if (!options.multi) {                                                                                        // 119
      findOptions.limit = 1;                                                                                     // 120
    }                                                                                                            // 121
  }                                                                                                              // 122
                                                                                                                 // 123
  // Unlike validators, we iterate over multiple docs, so use                                                    // 124
  // find instead of findOne:                                                                                    // 125
  return collection.find(selector, findOptions);                                                                 // 126
};                                                                                                               // 127
                                                                                                                 // 128
CollectionHooks.reassignPrototype = function (instance, constr) {                                                // 129
  var hasSetPrototypeOf = typeof Object.setPrototypeOf === "function";                                           // 130
                                                                                                                 // 131
  if (!constr) constr = Meteor.Collection;                                                                       // 132
                                                                                                                 // 133
  // __proto__ is not available in < IE11                                                                        // 134
  // Note: Assigning a prototype dynamically has performance implications                                        // 135
  if (hasSetPrototypeOf) {                                                                                       // 136
    Object.setPrototypeOf(instance, constr.prototype);                                                           // 137
  } else if (instance.__proto__) {                                                                               // 138
    instance.__proto__ = constr.prototype;                                                                       // 139
  }                                                                                                              // 140
};                                                                                                               // 141
                                                                                                                 // 142
Meteor.Collection = function () {                                                                                // 143
  var ret = constructor.apply(this, arguments);                                                                  // 144
  CollectionHooks.extendCollectionInstance(this);                                                                // 145
  return ret;                                                                                                    // 146
};                                                                                                               // 147
                                                                                                                 // 148
Meteor.Collection.prototype = proto;                                                                             // 149
                                                                                                                 // 150
for (var prop in constructor) {                                                                                  // 151
  if (constructor.hasOwnProperty(prop)) {                                                                        // 152
    Meteor.Collection[prop] = constructor[prop];                                                                 // 153
  }                                                                                                              // 154
}                                                                                                                // 155
                                                                                                                 // 156
if (Meteor.isServer) {                                                                                           // 157
  var _publish = Meteor.publish;                                                                                 // 158
  Meteor.publish = function (name, func) {                                                                       // 159
    return _publish.call(this, name, function () {                                                               // 160
      currentUserId = this && this.userId;                                                                       // 161
      var ret = func.apply(this, arguments);                                                                     // 162
      currentUserId = undefined;                                                                                 // 163
      return ret;                                                                                                // 164
    });                                                                                                          // 165
  };                                                                                                             // 166
}                                                                                                                // 167
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/insert.js                                                                           //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
CollectionHooks.defineAdvice("insert", function (userId, _super, aspects, getTransform, args) {                  // 1
  var self = this;                                                                                               // 2
  var ctx = {context: self, _super: _super, args: args};                                                         // 3
  var callback = _.last(args);                                                                                   // 4
  var async = _.isFunction(callback);                                                                            // 5
  var abort, ret;                                                                                                // 6
                                                                                                                 // 7
  // args[0] : doc                                                                                               // 8
  // args[1] : callback                                                                                          // 9
                                                                                                                 // 10
  // before                                                                                                      // 11
  _.each(aspects.before, function (aspect) {                                                                     // 12
    var r = aspect.call(_.extend({transform: getTransform(args[0])}, ctx), userId, args[0]);                     // 13
    if (r === false) abort = true;                                                                               // 14
  });                                                                                                            // 15
                                                                                                                 // 16
  if (abort) return false;                                                                                       // 17
                                                                                                                 // 18
  function after(id, err) {                                                                                      // 19
    var doc = args[0];                                                                                           // 20
    if (id) {                                                                                                    // 21
      doc = EJSON.clone(args[0]);                                                                                // 22
      doc._id = id;                                                                                              // 23
    }                                                                                                            // 24
    var lctx = _.extend({transform: getTransform(doc), _id: id, err: err}, ctx);                                 // 25
    _.each(aspects.after, function (aspect) {                                                                    // 26
      aspect.call(lctx, userId, doc);                                                                            // 27
    });                                                                                                          // 28
    return id;                                                                                                   // 29
  }                                                                                                              // 30
                                                                                                                 // 31
  if (async) {                                                                                                   // 32
    args[args.length - 1] = function (err, obj) {                                                                // 33
      after(obj && obj[0] && obj[0]._id || obj, err);                                                            // 34
      return callback.apply(this, arguments);                                                                    // 35
    };                                                                                                           // 36
    return _super.apply(self, args);                                                                             // 37
  } else {                                                                                                       // 38
    ret = _super.apply(self, args);                                                                              // 39
    return after(ret && ret[0] && ret[0]._id || ret);                                                            // 40
  }                                                                                                              // 41
});                                                                                                              // 42
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/update.js                                                                           //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
CollectionHooks.defineAdvice("update", function (userId, _super, aspects, getTransform, args) {                  // 1
  var self = this;                                                                                               // 2
  var ctx = {context: self, _super: _super, args: args};                                                         // 3
  var callback = _.last(args);                                                                                   // 4
  var async = _.isFunction(callback);                                                                            // 5
  var docs, docsIds, fields, abort, prev = {};                                                                   // 6
  var collection = _.has(self, "_collection") ? self._collection : self;                                         // 7
                                                                                                                 // 8
  // args[0] : selector                                                                                          // 9
  // args[1] : mutator                                                                                           // 10
  // args[2] : options (optional)                                                                                // 11
  // args[3] : callback                                                                                          // 12
                                                                                                                 // 13
  if (_.isFunction(args[2])) {                                                                                   // 14
    callback = args[2];                                                                                          // 15
    args[2] = {};                                                                                                // 16
  }                                                                                                              // 17
                                                                                                                 // 18
  if (aspects.before || aspects.after) {                                                                         // 19
    fields = getFields(args[1]);                                                                                 // 20
    docs = CollectionHooks.getDocs.call(self, collection, args[0], args[2]).fetch();                             // 21
    docIds = _.map(docs, function (doc) { return doc._id; });                                                    // 22
  }                                                                                                              // 23
                                                                                                                 // 24
  // copy originals for convenience for the "after" pointcut                                                     // 25
  if (aspects.after) {                                                                                           // 26
    prev.mutator = EJSON.clone(args[1]);                                                                         // 27
    prev.options = EJSON.clone(args[2]);                                                                         // 28
    prev.docs = {};                                                                                              // 29
    _.each(docs, function (doc) {                                                                                // 30
      prev.docs[doc._id] = EJSON.clone(doc);                                                                     // 31
    });                                                                                                          // 32
  }                                                                                                              // 33
                                                                                                                 // 34
  // before                                                                                                      // 35
  _.each(aspects.before, function (aspect) {                                                                     // 36
    _.each(docs, function (doc) {                                                                                // 37
      var r = aspect.call(_.extend({transform: getTransform(doc)}, ctx), userId, doc, fields, args[1], args[2]); // 38
      if (r === false) abort = true;                                                                             // 39
    });                                                                                                          // 40
  });                                                                                                            // 41
                                                                                                                 // 42
  if (abort) return false;                                                                                       // 43
                                                                                                                 // 44
  function after(affected, err) {                                                                                // 45
    var fields = getFields(args[1]);                                                                             // 46
    var docs = CollectionHooks.getDocs.call(self, collection, {_id: {$in: docIds}}, args[2]).fetch();            // 47
                                                                                                                 // 48
    _.each(aspects.after, function (aspect) {                                                                    // 49
      _.each(docs, function (doc) {                                                                              // 50
        aspect.call(_.extend({                                                                                   // 51
          transform: getTransform(doc),                                                                          // 52
          previous: prev.docs[doc._id],                                                                          // 53
          affected: affected,                                                                                    // 54
          err: err                                                                                               // 55
        }, ctx), userId, doc, fields, prev.mutator, prev.options);                                               // 56
      });                                                                                                        // 57
    });                                                                                                          // 58
  }                                                                                                              // 59
                                                                                                                 // 60
  if (async) {                                                                                                   // 61
    args[args.length - 1] = function (err, affected) {                                                           // 62
      after(affected, err);                                                                                      // 63
      return callback.apply(this, arguments);                                                                    // 64
    };                                                                                                           // 65
    return _super.apply(this, args);                                                                             // 66
  } else {                                                                                                       // 67
    var affected = _super.apply(self, args);                                                                     // 68
    after(affected);                                                                                             // 69
    return affected;                                                                                             // 70
  }                                                                                                              // 71
});                                                                                                              // 72
                                                                                                                 // 73
// This function contains a snippet of code pulled and modified from:                                            // 74
// ~/.meteor/packages/mongo-livedata/collection.js:632-668                                                       // 75
// It's contained in these utility functions to make updates easier for us in                                    // 76
// case this code changes.                                                                                       // 77
var getFields = function (mutator) {                                                                             // 78
  // compute modified fields                                                                                     // 79
  var fields = [];                                                                                               // 80
  _.each(mutator, function (params, op) {                                                                        // 81
    _.each(_.keys(params), function (field) {                                                                    // 82
      // treat dotted fields as if they are replacing their                                                      // 83
      // top-level part                                                                                          // 84
      if (field.indexOf('.') !== -1)                                                                             // 85
        field = field.substring(0, field.indexOf('.'));                                                          // 86
                                                                                                                 // 87
      // record the field we are trying to change                                                                // 88
      if (!_.contains(fields, field))                                                                            // 89
        fields.push(field);                                                                                      // 90
    });                                                                                                          // 91
  });                                                                                                            // 92
                                                                                                                 // 93
  return fields;                                                                                                 // 94
};                                                                                                               // 95
                                                                                                                 // 96
// This function contains a snippet of code pulled and modified from:                                            // 97
// ~/.meteor/packages/mongo-livedata/collection.js                                                               // 98
// It's contained in these utility functions to make updates easier for us in                                    // 99
// case this code changes.                                                                                       // 100
var getFields = function (mutator) {                                                                             // 101
  // compute modified fields                                                                                     // 102
  var fields = [];                                                                                               // 103
                                                                                                                 // 104
  _.each(mutator, function (params, op) {                                                                        // 105
    //====ADDED START=======================                                                                     // 106
    if (_.contains(["$set", "$unset", "$inc", "$push", "$pull", "$pop", "$rename", "$pullAll", "$addToSet", "$bit"], op)) {
    //====ADDED END=========================                                                                     // 108
      _.each(_.keys(params), function (field) {                                                                  // 109
        // treat dotted fields as if they are replacing their                                                    // 110
        // top-level part                                                                                        // 111
        if (field.indexOf('.') !== -1)                                                                           // 112
          field = field.substring(0, field.indexOf('.'));                                                        // 113
                                                                                                                 // 114
        // record the field we are trying to change                                                              // 115
        if (!_.contains(fields, field))                                                                          // 116
          fields.push(field);                                                                                    // 117
      });                                                                                                        // 118
    //====ADDED START=======================                                                                     // 119
    } else {                                                                                                     // 120
      fields.push(op);                                                                                           // 121
    }                                                                                                            // 122
    //====ADDED END=========================                                                                     // 123
  });                                                                                                            // 124
                                                                                                                 // 125
  return fields;                                                                                                 // 126
};                                                                                                               // 127
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/remove.js                                                                           //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
CollectionHooks.defineAdvice("remove", function (userId, _super, aspects, getTransform, args) {                  // 1
  var self = this;                                                                                               // 2
  var ctx = {context: self, _super: _super, args: args};                                                         // 3
  var callback = _.last(args);                                                                                   // 4
  var async = _.isFunction(callback);                                                                            // 5
  var docs, abort, prev = [];                                                                                    // 6
  var collection = _.has(self, "_collection") ? self._collection : self;                                         // 7
                                                                                                                 // 8
  // args[0] : selector                                                                                          // 9
  // args[1] : callback                                                                                          // 10
                                                                                                                 // 11
  if (aspects.before || aspects.after) {                                                                         // 12
    docs = CollectionHooks.getDocs.call(self, collection, args[0]).fetch();                                      // 13
  }                                                                                                              // 14
                                                                                                                 // 15
  // copy originals for convenience for the "after" pointcut                                                     // 16
  if (aspects.after) {                                                                                           // 17
    _.each(docs, function (doc) {                                                                                // 18
      prev.push(EJSON.clone(doc));                                                                               // 19
    });                                                                                                          // 20
  }                                                                                                              // 21
                                                                                                                 // 22
  // before                                                                                                      // 23
  _.each(aspects.before, function (aspect) {                                                                     // 24
    _.each(docs, function (doc) {                                                                                // 25
      var r = aspect.call(_.extend({transform: getTransform(doc)}, ctx), userId, doc);                           // 26
      if (r === false) abort = true;                                                                             // 27
    });                                                                                                          // 28
  });                                                                                                            // 29
                                                                                                                 // 30
  if (abort) return false;                                                                                       // 31
                                                                                                                 // 32
  function after(err) {                                                                                          // 33
    _.each(aspects.after, function (aspect) {                                                                    // 34
      _.each(prev, function (doc) {                                                                              // 35
        aspect.call(_.extend({transform: getTransform(doc), err: err}, ctx), userId, doc);                       // 36
      });                                                                                                        // 37
    });                                                                                                          // 38
  }                                                                                                              // 39
                                                                                                                 // 40
  if (async) {                                                                                                   // 41
    args[args.length - 1] = function (err) {                                                                     // 42
      after(err);                                                                                                // 43
      return callback.apply(this, arguments);                                                                    // 44
    };                                                                                                           // 45
    return _super.apply(self, args);                                                                             // 46
  } else {                                                                                                       // 47
    var result = _super.apply(self, args);                                                                       // 48
    after();                                                                                                     // 49
    return result;                                                                                               // 50
  }                                                                                                              // 51
});                                                                                                              // 52
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/find.js                                                                             //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
CollectionHooks.defineAdvice("find", function (userId, _super, aspects, getTransform, args) {                    // 1
  var self = this;                                                                                               // 2
  var ctx = {context: self, _super: _super, args: args};                                                         // 3
  var ret, abort;                                                                                                // 4
                                                                                                                 // 5
  // args[0] : selector                                                                                          // 6
  // args[1] : options                                                                                           // 7
                                                                                                                 // 8
  // before                                                                                                      // 9
  _.each(aspects.before, function (aspect) {                                                                     // 10
    var r = aspect.call(ctx, userId, args[0], args[1]);                                                          // 11
    if (r === false) abort = true;                                                                               // 12
  });                                                                                                            // 13
                                                                                                                 // 14
  if (abort) return false;                                                                                       // 15
                                                                                                                 // 16
  function after(cursor) {                                                                                       // 17
    _.each(aspects.after, function (aspect) {                                                                    // 18
      aspect.call(ctx, userId, args[0], args[1], cursor);                                                        // 19
    });                                                                                                          // 20
  }                                                                                                              // 21
                                                                                                                 // 22
  ret = _super.apply(self, args);                                                                                // 23
  after(ret);                                                                                                    // 24
                                                                                                                 // 25
  return ret;                                                                                                    // 26
});                                                                                                              // 27
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/findone.js                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
CollectionHooks.defineAdvice("findOne", function (userId, _super, aspects, getTransform, args) {                 // 1
  var self = this;                                                                                               // 2
  var ctx = {context: self, _super: _super, args: args};                                                         // 3
  var ret, abort;                                                                                                // 4
                                                                                                                 // 5
  // args[0] : selector                                                                                          // 6
  // args[1] : options                                                                                           // 7
                                                                                                                 // 8
  // before                                                                                                      // 9
  _.each(aspects.before, function (aspect) {                                                                     // 10
    var r = aspect.call(ctx, userId, args[0], args[1]);                                                          // 11
    if (r === false) abort = true;                                                                               // 12
  });                                                                                                            // 13
                                                                                                                 // 14
  if (abort) return false;                                                                                       // 15
                                                                                                                 // 16
  function after(doc) {                                                                                          // 17
    _.each(aspects.after, function (aspect) {                                                                    // 18
      aspect.call(ctx, userId, args[0], args[1], doc);                                                           // 19
    });                                                                                                          // 20
  }                                                                                                              // 21
                                                                                                                 // 22
  ret = _super.apply(self, args);                                                                                // 23
  after(ret);                                                                                                    // 24
                                                                                                                 // 25
  return ret;                                                                                                    // 26
});                                                                                                              // 27
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// packages/collection-hooks/users-compat.js                                                                     //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.users) {                                                                                              // 1
  // If Meteor.users has been instantiated, attempt to re-assign its prototype:                                  // 2
  CollectionHooks.reassignPrototype(Meteor.users);                                                               // 3
                                                                                                                 // 4
  // Next, give it the hook aspects:                                                                             // 5
  CollectionHooks.extendCollectionInstance(Meteor.users);                                                        // 6
}                                                                                                                // 7
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['collection-hooks'] = {
  CollectionHooks: CollectionHooks
};

})();
